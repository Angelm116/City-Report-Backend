module.exports = {
  HOST: "city-report-db.cbfpv7jn39fv.us-east-2.rds.amazonaws.com",
  USER: "cradmin",
  PASSWORD: "MasterPassword2021",
  DB: "report_schema"
};